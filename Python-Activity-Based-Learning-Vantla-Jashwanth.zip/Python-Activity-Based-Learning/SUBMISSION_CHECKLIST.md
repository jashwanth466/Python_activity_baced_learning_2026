# Submission Checklist
- [ ] Review all 10 topics with faculty's expectations.
- [ ] Run each `program.py` and verify test cases.
- [ ] Capture genuine screenshots of your own program runs (the included PNGs are sample illustrations, not captured executions).
- [ ] Review flowcharts and improve them if your faculty requires drawn flowchart symbols.
- [ ] Read and understand each program before demonstration.
- [ ] Create a GitHub repository named `Python-Activity-Based-Learning`.
- [ ] Upload all folders, `README.md`, and `ABL_Consolidated_Report.pdf`.
- [ ] Copy the repository URL and submit it by 22 October 2026.
