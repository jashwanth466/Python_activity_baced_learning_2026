# Python Activity-Based Learning (ABL) Assignment

## Student Details
- **Name:** Vantla Jashwanth
- **Roll Number:** 26001859
- **Branch:** CSE – Cyber Security
- **Section:** 21

## Selected Case Studies
13. **ATM Transaction Sequence Simulation**
17. **Student Performance Trend Analysis**
23. **Student Timetable Conflict Detection**
29. **Password Policy Validation Engine**
35. **Text Compression Using Character Runs**
42. **Student Marks Matrix Analysis**
47. **Sports Tournament Ranking System**
57. **Smart Canteen Order and Stock Management**
66. **Student Academic Risk Classification**
74. **Campus Festival Registration and Financial Audit**

## Repository Contents
Each case-study folder contains:
- `program.py` — Python source code
- `documentation.md` — problem statement, objectives, assumptions, algorithm, flowchart (Mermaid), pseudocode, test cases, sample run, and conclusion
- `output_screenshot.png` — terminal-style sample output image

`ABL_Consolidated_Report.pdf` contains the consolidated report.

## How to Run
1. Install Python 3.
2. Open a terminal in the required case-study folder.
3. Run `python program.py`.
4. Enter the sample data requested by the program.

## Notes
- The programs use the syllabus concepts specified in the assignment, such as variables, operators, conditions, loops, strings, lists, nested lists, tuples, and unpacking.
- Thresholds and policies are stated as educational assumptions and can be changed if your faculty provides different rules.
- Review and test every program yourself before submission so you can explain its logic during demonstration.
